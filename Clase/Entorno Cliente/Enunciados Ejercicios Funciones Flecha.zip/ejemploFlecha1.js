// declarando la funcion

let saludar = nombre => 'Hola ' + nombre

console.log (saludar("coca cola"))

let gastar = (gasto1,nombre)=> 'hola '+nombre+' tus gastos son '+gasto1
console.log (gastar(45000,'Alejo'))
