function saludar (nombre){

    return (`Hola ${nombre}`)

}
console.log (saludar("coca cola"))
