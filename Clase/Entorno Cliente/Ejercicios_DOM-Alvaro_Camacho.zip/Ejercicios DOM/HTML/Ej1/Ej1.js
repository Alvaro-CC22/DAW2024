window.onload = function() {
    document.body.style.backgroundColor = "yellow";
    document.body.style.fontFamily='Courier'
    document.body.style.margin='40px'
    document.body.style.border='1px solid #f00'
    document.body.style.padding='20px'
    
};