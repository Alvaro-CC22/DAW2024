function muestra() {
    var textoAdicional = document.querySelector('.adicional');

    textoAdicional.style.display = 'inline';

    var enlace = document.querySelector('.enlace');
    enlace.style.display = 'none';
}