let numRan = (num) => {
    return (Math.floor((Math.random() * num) + 1));
}

console.log(numRan(12));
console.log(numRan(241));
console.log(numRan(42851));