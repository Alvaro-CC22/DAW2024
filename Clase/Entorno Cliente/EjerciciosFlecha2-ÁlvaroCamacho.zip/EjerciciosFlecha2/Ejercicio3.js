let ºCaºF = (gradosC) => {
    return (gradosC * 9 / 5) + 32
}

console.log(ºCaºF(15));
console.log(ºCaºF(33));