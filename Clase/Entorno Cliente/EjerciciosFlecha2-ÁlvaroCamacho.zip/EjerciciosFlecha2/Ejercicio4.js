let tablaMultiplicar = (num) =>{
    for(let i = 1; i <= 10; i++){
        console.log(num, " x ", i, " = ", (num*i));
    }
}

tablaMultiplicar(2);
tablaMultiplicar(33);
tablaMultiplicar(200);