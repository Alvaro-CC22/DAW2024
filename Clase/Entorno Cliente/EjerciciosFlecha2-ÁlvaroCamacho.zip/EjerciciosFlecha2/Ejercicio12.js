let redondeaPi = () =>{
    return Math.PI.toFixed(2);
}

console.log(redondeaPi())