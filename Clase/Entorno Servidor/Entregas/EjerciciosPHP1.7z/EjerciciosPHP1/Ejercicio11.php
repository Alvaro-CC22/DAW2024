<?php
// Crea una constante llamada STOCK que tenga el valor 100 y que distinga entre minúsculas/mayúsculas

$STOCK = 100;

echo $STOCK, "<br>";
?>