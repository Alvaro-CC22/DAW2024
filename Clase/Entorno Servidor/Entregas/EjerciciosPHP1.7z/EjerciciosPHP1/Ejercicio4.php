<?php
//Escribe el código necesario para mostrar la estatura de Alberto

$estaturas = [
    "Juan" => 186,
    "Alberto" => 172,
    "Marta" => 173
];

echo $estaturas["Alberto"], "cm";
?>