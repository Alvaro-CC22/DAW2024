<?php
// Completa el siguiente código para que muestre el número de elementos del array $frutas:
$frutas = array("Manzana", "Plátano", "Naranja");

echo count($frutas);
?>