<?php
//Crea un array asociativo llamado $estaturas que contenga la estatura de las siguientes personas

$estaturas = [
    "Juan" => 186,
    "Alberto" => 172,
    "Marta" => 173
];

?>