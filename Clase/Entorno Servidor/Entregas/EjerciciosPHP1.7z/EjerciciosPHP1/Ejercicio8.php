<?php
//Ordena alfabéticamente el siguiente array:
$colores = array("rojo", "verde", "azul", "amarillo");

sort($colores);

foreach ($colores as $value ){
    echo "$value <br>";
}
?>