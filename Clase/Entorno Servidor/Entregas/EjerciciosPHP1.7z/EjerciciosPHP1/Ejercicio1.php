<?php
    //Crea 2 variables llamadas $x1 y $x2. Almacena un valor numérico en ellas y posteriormente
    //muestra en pantalla la suma de ellas.
    $x1 = 33;
    $x2 = 36;

    echo "La suma de $x1 y $x2 da ", $x1 + $x2;
?>