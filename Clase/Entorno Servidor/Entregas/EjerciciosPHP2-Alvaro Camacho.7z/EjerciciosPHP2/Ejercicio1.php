<?php
    //Write a PHP script to get the PHP version and configuration information
    phpinfo();
?>