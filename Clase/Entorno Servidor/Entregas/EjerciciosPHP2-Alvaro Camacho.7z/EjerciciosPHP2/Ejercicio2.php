<?php
    //Write a PHP script to display the following strings.
    //Sample String :
    //'Tomorrow I \'ll learn PHP global variables.'
    //'This is a bad command : del c:\\*.*'
    //Expected Output :
    //Tomorrow I 'll learn PHP global variables.
    //This is a bad command : del c:\*.*
    
    echo "Tomorrow I \'ll learn PHP global variables.". "<br>";
    echo "This is a bad command : del c:\\*.*". "<br>";
?>
